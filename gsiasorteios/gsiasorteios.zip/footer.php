		<div id="block-footer">
			<div class="wrapper">
				<footer id="footer">
					<a id="totop-scroller" href="#page">
					</a>
					<div class="module   deepest">
						<ul class="menu menu-line">
							<li class="level1 item108">
								<a href="index.php/features.html" class="level1">
									<span>Página Inicial</span>
								</a>
							</li>
							<li class="level1 item109">
								<a href="index.php/features/typography.html" class="level1">
									<span>Quem Somos</span>
								</a>
							</li>
							<li class="level1 item110">
								<a href="index.php/joomla.html" class="level1">
									<span>Contato</span>
								</a>
							</li>
						</ul>		
					</div>
					<div class="module   deepest">
						Goianésia Sorteios Copyright &copy; 2015  
						<a href="http://rankedgamingbrasil.com.br/" target="_blank">
							GSIASorteios
						</a>		
					</div>			
				</footer>
			</div>
		</div>	
		<script type="text/javascript"><!--
			function CheckUserSorteio(produto_nome, user_id, sorteio_id) {
				if (user_id == '') {
					$("#div_info_process").removeClass('box-success');
	                $("#div_info_process").addClass('box-warning');
					$("#div_info_process").html('Olá! Apenas contas registradas e confirmadas podem participar dos sorteios! <br> Você está sendo redirecionado para a página de cadastro...');
                	$("#div_info_process").fadeIn(1000);
                	setTimeout('location.href="' + app.base + 'docs/cadastro/"', 10000);	
				} else {
					$.ajax({
	                    type: "POST",
	                    url : app.base + "includes/join_customer.php",
	                    data: {act_accounts_id: user_id, sor_sorteios_id: sorteio_id},
	                    dataType : "html",

	                    success : function(data) { 
	                        if (data.indexOf('1') > 0) {
	                        	$("#div_info_process").html('Sucesso! Agora você está participando do sorteio de <b> ' + produto_nome + '</b>');
	                        	$("#div_info_process").fadeIn(1000);
	                        	$("#div_info_process").removeClass('box-warning');
	                        	$("#div_info_process").addClass('box-success');
	                        	setTimeout('javascript:$("#div_info_process").fadeOut(5000)', 5000);
	                        } else if (data.indexOf('2') > 0) {
	                        	$("#div_info_process").removeClass('box-success');
	                        	$("#div_info_process").addClass('box-warning');
	                        	$("#div_info_process").html('Ops! Você já está participando deste sorteio! Aguarde até o dia do sorteio e boa sorte!');
							    $("#div_info_process").fadeIn(1000);
	                        	setTimeout('javascript:$("#div_info_process").fadeOut(5000)', 5000);
	                        } else {
	                        	$("#div_info_process").removeClass('box-success');
	                        	$("#div_info_process").addClass('box-warning');
	                        	$("#div_info_process").html('Falha! :( Ocorreu um problema ao participar deste sorteio. Tente novamente mais tarde.');
							    $("#div_info_process").css('display', 'block');
	                        }
	                    }
	                });
				}
			}
		//--></script>		
	</body>
</html>