<?php 
  include '../../header.php';
?>
        <section id="bottom-a" class="grid-block">
          <div class="grid-box width100 grid-h">
            <div class="module deepest">    
              <div class="frontpage">
                <div id="accordion-30-5317bb4873dca" class="wk-accordion wk-accordion-default clearfix" style="width: 1000px;" data-widgetkit="accordion" data-options='{"style":"default","collapseall":1,"matchheight":1,"index":99999999,"duration":500,"width":500}'>
                  <div class="box-info">
                    <center> 
                      <?php 
                        if ( (isset($_POST['act_account_email'])) AND (isset($_POST['act_account_senha'])) ) {
                          if ($user->isLoggedUser()) { ?>
                            Você já está logado e será redirecionado para a página anterior.
                          <?php } else {
                            if ($user->loginUser($_POST['act_account_email'], $_POST['act_account_senha'])) { ?>
                              Logado com sucesso! Redirecionando para a página anterior...
                            <?php } else { ?>
                              Dados incorretos! Tente novamente.
                            <?php } 
                          } 
                        }
                      ?>
                    </center>
                  </div>
                </div>
              </div>    
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</div>

  <script type="text/javascript"><!--
    $(document).ready(function() {
      setTimeout('javascript:window.history.go(-1)', 3000);
    });
  //--></script>
<?php include '../../footer.php'; ?>