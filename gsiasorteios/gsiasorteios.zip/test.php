<?php
/* 
%Y = Ano
%M = Meses
%D = Dias
%H = Horas
%I = Minutos
%S = Segundos
%a = Total de Dias
*/

date_default_timezone_set('America/Sao_Paulo');
 
$inicio = date('d/m/Y H:i:s');
$fim = '28/08/2015 17:13:24';

// Converte as datas para objetos DateTime do PHP
// PARA O PHP 5.3 OU SUPERIOR
$inicio = DateTime::createFromFormat('d/m/Y H:i:s', $inicio);
 
//PARA O PHP 5.2
// $inicio = date_create_from_format('d/m/Y H:i:s', $inicio);
 
$fim = DateTime::createFromFormat('d/m/Y H:i:s', $fim);
// $fim = date_create_from_format('d/m/Y H:i:s', $fim);
 
// Calcula a diferença entre as duas datas
$intervalo = $inicio->diff($fim);
 
// Imprime a diferença entre as duas
$result = array( 'days' => $intervalo->format('%D'),
      'hours' => $intervalo->format('%H'),
      'minutes' => $intervalo->format('%I'),
      'seconds' => $intervalo->format('%S'));
?>